window.onload = consultaAPI()



  async function consultaAPI() {

    
    const response = await fetch(transformaURL())
    // console.log(response)
    const repo = await response.json();
    console.log(repo)

    document.getElementById('nomeSuperior').innerHTML =`
    <a class="nome" href="/public/index.html">${repo.owner.login}</a>`;

    document.getElementById('nome').innerHTML = `Repositório: ${repo.name}`
    document.getElementById('pbio').textContent = repo.description
    document.getElementById('dataCriacao').textContent = repo.created_at

    if (repo.language == null) {
      document.getElementById('linguagem').textContent = `Não informada`
    } else {
      document.getElementById('linguagem').textContent = repo.language
    }
    urlNova = repo.clone_url.replace(".git", "");
    // console.log(urlNova)
    document.getElementById('linkRepositorio').href = urlNova
    // document.getElementById('linkRepositorio').target = "_blank"
    document.getElementById('linkRepositorio').innerHTML = urlNova


    for (let i = 0; i < repo.topics.length; i++) {
      document.getElementById('topicos').innerHTML += `
      <span class="topicos">
        ${repo.topics[i]}
      </span>`
    }

    document.getElementById('nSeguidores').innerHTML = `
    <i class="fa-solid fa-star fa-2xl" style="color: #878787;"></i>${repo.stargazers_count}
    <br>
    <br>
    <i class="fa-solid fa-user fa-2xl"></i>${repo.watchers_count}`
    // <br>
    // <br>
    // <i class="fa-solid fa-code-fork fa-2xl"></i>${repo.forks}
  }

  function transformaURL() {

    endereco = (window.location.search).replace("?dono=", "")
    endereco = endereco.replace("repo=", "")
    resultado = "https://api.github.com/repos/" + endereco.replace("&", "/")

    return resultado
  }